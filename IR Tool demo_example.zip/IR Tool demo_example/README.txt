Raging Bits IR Tool DEMO/EXAMPLE.

This software is provided as AN EXAMPLE to demonstrate the ability of the IR Tool device.
Use at own risk, no garantees nor responsability for any problems that may come from it use.
Feel free to use/modify under the GNU license terms. 

This demo/example has been built using Visual Studio, so it will need Microsoft.NET Framework in order to work.

raging.bits@outlook.com
