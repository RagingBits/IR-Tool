Raging Bits IR Tool demo.

This software is provided as AN EXAMPLE to demonstrate the ability of the IR Tool device.
Feel free to use/modify at own risk, under the GNU license terms. 

raging.bits@outlook.com
